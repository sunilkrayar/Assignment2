
let checkLogin =(email,password,allUsers)=>{   //decalaring arrow function with parameter//
   let isUserFound=false; //declaring boolean value//
  let  passwordCorrect=false;
 for(currentUser of allUsers){ //itarating through for of llop//
  console.log(currentUser)//printing currentUser//
  if(currentUser.email==email){ //checking condition for email match
  if(currentUser.password==password){//condition for password//
    isUserFound=true//if condition true boolean value excute
    passwordCorrect=true
    }else{
      isUserFound=true////if condition fails then this else condition excute
      passwordCorrect=false
    }

  }
  else{
    isUserFound=false//

  }
  }
  //end of loop

 
if(isUserFound==true && passwordCorrect==true){//condition for checking enter email and paasword mtach or not//
  alert('looged in')//matched print this
}else if(isUserFound==true && passwordCorrect==false){//if condition for checking proper input
  alert('wrong password')//print if true
}else{
  alert('invalid entry')//all condition false then this else statement execute
}
}
//------------------------------------//
//swapping program//

let bubble_sort =(a)=>{ //decalring arrow function along parameter
  let swapp;//intializing variable using let keyword
  let n=a.length-1;
  let x=a;//assing x as a//

  do{ //working on do-while loop
           swapp=false //declaring condition using boolean
             for(let i=0;i<n;i++){//itarating through for loop//
              if(x[i]<x[i+1]){//if condition for swapping
               let temp =x[i]//assing temp as x[i]
               x[i]=x[i+1]
               x[i+1]==temp//swapped
              swapp=true;
            }

             } n--;//decrementing--//
                        


             }while(swapp);//if above condition true it execute until condition become false
             return x;//returning x value

}